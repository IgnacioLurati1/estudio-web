// Super CVG (supercvg.lutastudios.com), the unofficial campus panel, shows the final grade of each subject the student
// passed in Sysacad. It always hears back, so it knows the extension is here, and gets the grades only if the student
// linked it (contenido.js keeps them from Estado académico). The page can also link or unlink it, like the switch in
// Ajustes. Everything stays in this same browser: nothing is sent anywhere.
(() => {
  'use strict';
  const limpios = (finales) =>
    (Array.isArray(finales) ? finales : [])
      .filter((f) => f && typeof f.nombre === 'string' && f.nombre.trim() && Number.isFinite(f.nota) && f.nota >= 1 && f.nota <= 10)
      .slice(0, 80)
      .map((f) => ({ nombre: f.nombre.trim().slice(0, 120), nota: f.nota }));

  const contestar = async () => {
    const { supercvgVinculado, supercvgFinales } = await chrome.storage.local.get({ supercvgVinculado: false, supercvgFinales: null });
    const mensaje = { fuente: 'sysacad-lindo', para: 'super-cvg', v: 1, vinculada: supercvgVinculado === true };
    if (mensaje.vinculada && supercvgFinales && Array.isArray(supercvgFinales.finales) && Number.isFinite(supercvgFinales.fecha)) {
      mensaje.fecha = supercvgFinales.fecha;
      mensaje.finales = limpios(supercvgFinales.finales);
    }
    window.postMessage(mensaje, location.origin);
  };

  const PEDIDOS = {
    sysacad: () => contestar(),
    // Linked from here, Sysacad Lindo offers to go back here once it has read the grades.
    vincular: async () => {
      await chrome.storage.local.set({ supercvgVinculado: true, supercvgPreguntado: true, supercvgDesdeSuPagina: true });
      await contestar();
    },
    // Same as turning the switch off in Ajustes: what was kept goes away.
    desvincular: async () => {
      await chrome.storage.local.set({ supercvgVinculado: false, supercvgPreguntado: true });
      await chrome.storage.local.remove(['supercvgFinales', 'supercvgDesdeSuPagina']);
      await contestar();
    },
  };

  // Only the page itself asks: not a frame inside it, nor a window that opened it.
  window.addEventListener('message', (e) => {
    if (e.source !== window || e.origin !== location.origin || !e.data || e.data.fuente !== 'super-cvg') return;
    if (Object.hasOwn(PEDIDOS, e.data.pide)) PEDIDOS[e.data.pide]();
  });
  // The page asks when it is ready; this also answers once on its own, in case the page was first.
  contestar();
})();
